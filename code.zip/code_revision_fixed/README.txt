## README ##The R code files can be used to reproduce the results and figures presented in the manuscript.#### Main simulations ##### �sa_f.R�Can be used for the simulation with a tradeoff between adult survival and fecundity.# �sj_f.R�Can be used for the simulation with a tradeoff between juvenile survival and fecundity.# �sa_sj - intergenerational.R�Can be used for the simulation with an intergenerational tradeoff between parental adult survival and offspring juvenile survival.# �f_sj.R � intergenerational.R�Can be used for the simulation with an intergenerational tradeoff between parental fecundity and offspring juvenile survival.#### Supplementary analyses ###### Appendix B ##

# "sa_f_alternative.R"
Can be used for the simulation with an alternative method to change the covariation in Appendix 1, for a tradeoff between adult survival and fecundity.

# "sj_f_alternative.R"
Can be used for the simulation with an alternative method to change the covariation in Appendix 1, for a tradeoff between juvenile survival and fecundity.## Appendix D ### "appendix_density.R"
Can be used for the simulation with decreased density dependence (Appendix 3).

## Appendix E ##

# "a4_sa_f.R"
Can be used for the simulation of Appendix 4 with a tradeoff between adult survival and fecundity.

# "a4_sj_f.R"
Can be used for the simulation of Appendix 4 with a tradeoff between juvenile survival and fecundity.

# "a4_sa_sj.R"
Can be used for the simulation of Appendix 4 with an intergenerational tradeoff between parental adult survival and offspring juvenile survival.

# "a4_f_sj.R"
Can be used for the simulation of Appendix 4 with an intergenerational tradeoff between parental fecundity and offspring juvenile survival.


## methods animation ##

# "method_main.gif"
Animation displaying how individuals 'move' in the demographic-rate space as the environment changes, following the methods presented in the main text for intraindividual tradeoffs.

# " method_appendix.gif"
Animation displaying how individuals 'move' in the demographic-rate space as the environment changes, following the methods presented in the appendix for intraindividual tradeoffs.

